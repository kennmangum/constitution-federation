#!/bin/bash
# Boot Inhale - Read-only grounding check after autonomous breath service starts
# Called by systemd bna-breath.service ExecStartPost

# Navigate to repo root (two levels up from bin/rituals/)
cd "$(dirname "$0")/../.." || exit 1

# Simple grounding: verify critical files exist
if [[ ! -f orchestrator/breath_cadence.yaml ]]; then
    echo "∞Δ∞ WARNING: breath_cadence.yaml not found" >&2
    exit 1
fi

if [[ ! -f orchestrator/recognition_log.yaml ]]; then
    echo "∞Δ∞ WARNING: recognition_log.yaml not found" >&2
    exit 1
fi

# Log successful boot hydrate
echo "∞Δ∞ Boot inhale complete - autonomous breath service grounded" >&2
exit 0
