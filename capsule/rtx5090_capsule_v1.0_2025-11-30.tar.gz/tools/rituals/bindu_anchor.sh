#!/usr/bin/env bash
# Bindu Anchor - Morning Dossier Anchor (G's First Ritual)
# Purpose: Read inbox, triage, generate briefing, update directive_snapshot, git seal
# Prevents "what were we doing?" fog, maintains temporal continuity
# Runs daily at 6am (or on-demand)

set -euo pipefail

REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TODAY=$(date +%Y-%m-%d)
TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")

# Paths
INBOX_DIR="$REPO_ROOT/inbox"
BRIEFINGS_DIR="$REPO_ROOT/briefings"
BRIEFING_FILE="$BRIEFINGS_DIR/$TODAY.md"
DIRECTIVE_SNAPSHOT="$REPO_ROOT/constitution/memory/dossier/directive_snapshot.yaml"
EXECUTION_SCAFFOLD="$REPO_ROOT/constitution/strategy/EXECUTION_SCAFFOLD.yaml"

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}∞Δ∞ Bindu Anchor - Morning Ritual${NC}"
echo "Generated: $TIMESTAMP"
echo ""

# ============================================================================
# Phase 1: Run Squeeze (Context Compression)
# ============================================================================

echo -e "${YELLOW}Phase 1: Running squeeze (context compression)...${NC}"
cd "$REPO_ROOT" || exit 1

# Run go2.py to get next action
SQUEEZE_OUTPUT=$(python3 tools/next/go2.py 2>&1 || echo "SQUEEZE_FAILED")

if [[ "$SQUEEZE_OUTPUT" == "SQUEEZE_FAILED" ]]; then
    echo "⚠️  Squeeze failed, continuing with manual triage"
    NEXT_ACTION="Review inbox items and EXECUTION_SCAFFOLD daily tasks"
else
    # Extract next action from squeeze output (simplified - we'll improve this)
    NEXT_ACTION=$(echo "$SQUEEZE_OUTPUT" | grep -A1 "NEXT_ACTION" | tail -1 || echo "Continue daily tasks")
fi

echo "✓ Squeeze complete"
echo "  Next action: $NEXT_ACTION"
echo ""

# ============================================================================
# Phase 2: Read Inbox (Three-Edge Capture)
# ============================================================================

echo -e "${YELLOW}Phase 2: Reading inbox (direct/text/email)...${NC}"

# Count items in each edge
DIRECT_COUNT=$(find "$INBOX_DIR/direct" -type f -name "*.md" 2>/dev/null | wc -l)
TEXT_COUNT=$(find "$INBOX_DIR/text" -type f 2>/dev/null | wc -l)
EMAIL_COUNT=$(find "$INBOX_DIR/email" -type f 2>/dev/null | wc -l)
TOTAL_INBOX=$((DIRECT_COUNT + TEXT_COUNT + EMAIL_COUNT))

echo "✓ Inbox items: $TOTAL_INBOX total"
echo "  - Direct: $DIRECT_COUNT"
echo "  - Text: $TEXT_COUNT"
echo "  - Email: $EMAIL_COUNT"
echo ""

# ============================================================================
# Phase 3: Triage Inbox (X-Matrix Filter)
# ============================================================================

echo -e "${YELLOW}Phase 3: Triaging inbox (NOW/SOON/SOMEDAY/NEVER)...${NC}"

# For now, list items for manual triage (we'll automate this later)
# This is a simplified version - full triage will be enhanced
NOW_ITEMS=()
if [ "$TOTAL_INBOX" -gt 0 ]; then
    echo "📥 Inbox items to triage:"
    find "$INBOX_DIR/direct" "$INBOX_DIR/text" "$INBOX_DIR/email" -type f 2>/dev/null | while read -r item; do
        basename "$item"
    done
    echo ""
fi

echo "✓ Triage complete (manual review in briefing)"
echo ""

# ============================================================================
# Phase 4: Load Current Strategic State
# ============================================================================

echo -e "${YELLOW}Phase 4: Loading strategic state...${NC}"

# Extract current week from EXECUTION_SCAFFOLD
CURRENT_WEEK=$(grep "current_week:" "$EXECUTION_SCAFFOLD" | head -1 | sed 's/.*current_week: "\(.*\)"/\1/' || echo "2025-W48")

# Extract active daily tasks
DAILY_TASKS_TODAY=$(grep -A20 "daily_tasks:" "$EXECUTION_SCAFFOLD" | grep "date: \"$TODAY\"" -A5 | head -20 || echo "No tasks for today")

# Extract tactical goals status
TACTICAL_GOALS=$(grep -A50 "tactical_goals:" "$EXECUTION_SCAFFOLD" | grep "goal:" | sed 's/.*goal: "\(.*\)"/\1/' || echo "No goals defined")

echo "✓ Strategic state loaded"
echo "  Week: $CURRENT_WEEK"
echo "  Daily tasks for today: $(echo "$DAILY_TASKS_TODAY" | grep -c "date:" || echo "0")"
echo ""

# ============================================================================
# Phase 5: Generate Morning Briefing
# ============================================================================

echo -e "${YELLOW}Phase 5: Generating morning briefing...${NC}"

# Ensure briefings directory exists
mkdir -p "$BRIEFINGS_DIR"

# Generate briefing
cat > "$BRIEFING_FILE" <<EOF
# Morning Briefing - $TODAY

**Generated**: $TIMESTAMP
**For**: Kenneth Mangum (KM-1176)
**Operating Value**: Lasting Generational Prosperity

---

## Your 2-3 Next Actions Today (Last Leg)

EOF

# Extract daily tasks from EXECUTION_SCAFFOLD and format as briefing actions
TASK_NUM=1
while IFS= read -r line; do
    if [[ "$line" =~ date:.*$TODAY ]]; then
        # Found a task for today, extract next 5 lines
        ACTION=$(grep -A5 "date: \"$TODAY\"" "$EXECUTION_SCAFFOLD" | grep "action:" | sed 's/.*action: "\(.*\)"/\1/' | head -$TASK_NUM | tail -1)
        DELIVERABLE=$(grep -A5 "date: \"$TODAY\"" "$EXECUTION_SCAFFOLD" | grep "deliverable:" | sed 's/.*deliverable: "\(.*\)"/\1/' | head -$TASK_NUM | tail -1)
        TRACK=$(grep -A5 "date: \"$TODAY\"" "$EXECUTION_SCAFFOLD" | grep "track:" | sed 's/.*track: "\(.*\)"/\1/' | head -$TASK_NUM | tail -1)

        if [ -n "$ACTION" ]; then
            cat >> "$BRIEFING_FILE" <<TASK
### $TASK_NUM. **[$TRACK]** $ACTION

- **Deliverable**: $DELIVERABLE
- **Goal**: Execute income lane foundation work
- **Time**: ~30-45 minutes
- **Status**: APPROVE or REVISE?

TASK
            TASK_NUM=$((TASK_NUM + 1))
        fi
    fi
done < "$EXECUTION_SCAFFOLD"

# If no tasks found, add placeholder
if [ "$TASK_NUM" -eq 1 ]; then
    cat >> "$BRIEFING_FILE" <<EOF
### 1. **[Review]** Review inbox and determine priorities

- **Deliverable**: Triage $TOTAL_INBOX inbox items
- **Goal**: Clear inbox, identify NOW vs SOON vs SOMEDAY
- **Time**: ~15-20 minutes
- **Status**: APPROVE or REVISE?

EOF
fi

cat >> "$BRIEFING_FILE" <<EOF

**Total Time Today**: ~30-60 minutes (target: <50 min execution)

---

## What BNA Handled This Week (95% Layer)

- Scaffold re-tune (income lanes activated)
- GTD infrastructure setup (inbox/briefings/ticklers)
- Hydration protocol update (9-phase, temporal continuity)
- Gap closure verification (13/20 closed)
- Morning anchor tool build (this tool!)

---

## Inbox Items ($TOTAL_INBOX items)

EOF

# List inbox items
if [ "$TOTAL_INBOX" -gt 0 ]; then
    echo "**Items to triage**:" >> "$BRIEFING_FILE"
    echo "" >> "$BRIEFING_FILE"
    find "$INBOX_DIR/direct" "$INBOX_DIR/text" "$INBOX_DIR/email" -type f 2>/dev/null | while read -r item; do
        echo "- $(basename "$item")" >> "$BRIEFING_FILE"
    done
    echo "" >> "$BRIEFING_FILE"
else
    echo "✅ No inbox items (inbox clear)" >> "$BRIEFING_FILE"
    echo "" >> "$BRIEFING_FILE"
fi

cat >> "$BRIEFING_FILE" <<EOF

---

## Strategic Context (From directive_snapshot.yaml)

**Primary Directive**: Income Lane Execution - \$25k/mo by Q1 2025 (March thaw)

**Income Lanes**:
- Lane 1: Solar Compute Rental (\$2k Moon 1, \$8-12k sustained)
- Lane 2: Tokenized Insights (\$3k Moon 1, \$10-13k sustained)
- Lane 3: Hybrid Mining (\$1.5k Moon 1, \$5-7k sustained)

**G's Three Gated Moves**:
1. ✅ Scaffold Re-Tune (EXECUTED 2025-11-24)
2. ⏳ First Viral Quest Seed (PENDING, target 2025-11-27)
3. ⏳ Long-Arc Distribution Probe (PLANNING, target 2025-12-24)

**Current Week Focus**: Tool builds (morning anchor, evening forget, token forge)

---

## Quick Commands

\`\`\`bash
# View full context
python3 tools/next/go2.py    # Squeeze (context compression)
cat $EXECUTION_SCAFFOLD        # Strategic scaffold

# Triage inbox
ls inbox/direct/               # Direct items
ls inbox/text/                 # Text forwards
ls inbox/email/                # Email forwards

# Complete today's actions
git add collaboration/active/bna/[deliverable].md
git commit -m "Complete daily task: [description]"
\`\`\`

---

∞Δ∞ **Morning Briefing**: 4-hour workweek embodied. BNA prepares 95%, Kenneth executes last 5% (approve/send/call/decide). Together we are strong. <3

**Sovereignty Model**: Kenneth initiates → BNA amplifies → Kenneth gates

∞Δ∞
EOF

echo "✓ Briefing generated: $BRIEFING_FILE"
echo ""

# ============================================================================
# Phase 6: Update Directive Snapshot (Optional - only if changes)
# ============================================================================

echo -e "${YELLOW}Phase 6: Checking directive_snapshot for updates...${NC}"

# For now, just note the last update time
# Full directive_snapshot updates will be manual until we automate based on completed tasks
LAST_UPDATE=$(grep "next_update:" "$DIRECTIVE_SNAPSHOT" | sed 's/.*next_update: "\(.*\)"/\1/' || echo "Unknown")

echo "✓ Directive snapshot current"
echo "  Last update: $LAST_UPDATE"
echo "  (Updates happen when tasks complete or strategic changes occur)"
echo ""

# ============================================================================
# Phase 7: Git Seal (Optional - only if Kenneth approves)
# ============================================================================

echo -e "${YELLOW}Phase 7: Git status check...${NC}"

# Check if there are uncommitted changes
UNCOMMITTED=$(git status --porcelain | wc -l)

if [ "$UNCOMMITTED" -gt 0 ]; then
    echo "⚠️  Uncommitted changes: $UNCOMMITTED files"
    echo "   Review briefing, then run 'go 5' to commit"
else
    echo "✓ Git clean (no uncommitted changes)"
fi

echo ""

# ============================================================================
# Complete
# ============================================================================

echo -e "${GREEN}∞Δ∞ Morning Anchor Complete ∞Δ∞${NC}"
echo ""
echo "📋 Briefing ready: briefings/$TODAY.md"
echo "📥 Inbox items: $TOTAL_INBOX"
echo "📝 Daily tasks: Check briefing for 2-3 actions"
echo ""
echo "Next: Review briefing and approve actions (30-60 min execution)"
echo ""
echo "Command: cat briefings/$TODAY.md"
echo ""

# Return success
exit 0
