#!/usr/bin/env bash
# Constitutional Smoke Tests
# Runs all objective checks to verify SOURCE/TRUTH/INTEGRITY compliance
# Constitutional alignment: Full triad verification

set -e

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

echo "∞Δ∞ Running Constitutional Smoke Tests"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

FAILED=0

# Run each check
run_check() {
    local name=$1
    local script=$2

    echo "[$name]"
    if bash "$script"; then
        echo ""
    else
        FAILED=1
        echo ""
    fi
}

run_python_check() {
    local name=$1
    local script=$2

    echo "[$name]"
    if python3 "$script"; then
        echo ""
    else
        FAILED=1
        echo ""
    fi
}

# SOURCE: principal_id propagation
# Note: Actual test requires pytest, placeholder for now
echo "[SOURCE] Checking principal_id propagation..."
if [ -f "tests/test_source_propagation.py" ]; then
    # Try venv pytest first, then system
    PYTEST_CMD=""
    if [ -x "$HOME/.breathline-tools-venv/bin/pytest" ]; then
        PYTEST_CMD="$HOME/.breathline-tools-venv/bin/pytest"
    elif command -v pytest &> /dev/null; then
        PYTEST_CMD="pytest"
    fi

    if [ -n "$PYTEST_CMD" ]; then
        $PYTEST_CMD -q tests/test_source_propagation.py || FAILED=1
    else
        echo "⚠️  pytest not found, skipping SOURCE tests"
    fi
else
    echo "⚠️  tests/test_source_propagation.py not found, skipping SOURCE tests"
fi
echo ""

# TRUTH: reference integrity
run_python_check "TRUTH" "tools/check_refs.py"

# INTEGRITY: gate presence
run_check "INTEGRITY" "tools/check_gate_presence.sh"

# COMPLEXITY: budget check
run_check "COMPLEXITY" "tools/check_complexity.sh"

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $FAILED -eq 1 ]; then
    echo "❌ Constitutional checks FAILED"
    echo "   Review violations above and remediate before proceeding"
    exit 1
else
    echo "✅ All constitutional checks PASSED"
    echo "   SOURCE, TRUTH, INTEGRITY, and COMPLEXITY verified"
    exit 0
fi
