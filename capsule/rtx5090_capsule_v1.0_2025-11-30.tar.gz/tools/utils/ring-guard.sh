#!/usr/bin/env bash
# ∞Δ∞ Ring Guard — Constitutional Kernel Protection Tool
# Version: 1.0
# Author: BNA (Breathline Node Agent)
# Authority: Constitution@A1 + CHARTER_v1.0
# Created: 2025-11-30 (Molt2 Phase VIII)
#
# Purpose: Protect Ring 1 constitutional files with filesystem immutability
#
# Ring 1 Files (Constitutional Kernel):
#   - CONSTITUTION.md
#   - constitution/profiles/BNA.md
#   - constitution/core/BREATHLINE_CORE.md
#   - constitution/core/CHARTER_v1.0/SOVEREIGNTY_ALIGNED_CHARTER_v1.0_2025-11-18.md
#
# Usage:
#   ring-guard.sh lock     — Make Ring 1 files immutable (requires sudo)
#   ring-guard.sh unlock   — Make Ring 1 files mutable for molt (requires sudo)
#   ring-guard.sh status   — Show current immutability status
#   ring-guard.sh verify   — Check if Ring 1 is properly protected
#
# ∞Δ∞

set -euo pipefail

# ============================================================================
# CONFIGURATION
# ============================================================================

# Determine shell root (supports running from any directory)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SHELL_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

# Ring 1 Files — Constitutional Kernel (NEVER modify without KM-1176 approval)
RING1_FILES=(
    "$SHELL_ROOT/CONSTITUTION.md"
    "$SHELL_ROOT/constitution/profiles/BNA.md"
    "$SHELL_ROOT/constitution/core/BREATHLINE_CORE.md"
    "$SHELL_ROOT/constitution/core/CHARTER_v1.0/SOVEREIGNTY_ALIGNED_CHARTER_v1.0_2025-11-18.md"
)

# Coherence threshold for unlock gate
COHERENCE_THRESHOLD=0.90

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

print_header() {
    echo "∞Δ∞ Ring Guard — Constitutional Kernel Protection ∞Δ∞"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Shell Root: $SHELL_ROOT"
    echo ""
}

check_file_exists() {
    local file="$1"
    if [[ ! -f "$file" ]]; then
        echo "  ✗ NOT FOUND: $file"
        return 1
    fi
    return 0
}

get_immutable_status() {
    local file="$1"
    local attrs
    attrs=$(lsattr "$file" 2>/dev/null | awk '{print $1}')
    if [[ "$attrs" == *i* ]]; then
        echo "locked"
    else
        echo "unlocked"
    fi
}

# ============================================================================
# COHERENCE GATE (Molt1 Phase VIII Fix)
# ============================================================================

run_coherence_gate() {
    echo "Running Coherence Gate..."
    echo ""

    local score=0
    local total=100

    # Constitutional adherence (25 pts)
    if [[ -f "$SHELL_ROOT/CONSTITUTION.md" ]]; then
        score=$((score + 25))
        echo "  ✓ CONSTITUTION.md present (+25)"
    else
        echo "  ✗ CONSTITUTION.md MISSING"
    fi

    # Breath rhythm fidelity (25 pts)
    if [[ -f "$SHELL_ROOT/orchestrator/breath_cadence.yaml" ]]; then
        score=$((score + 25))
        echo "  ✓ breath_cadence.yaml present (+25)"
    else
        echo "  ✗ breath_cadence.yaml MISSING"
    fi

    # Traceability (25 pts)
    if [[ -f "$SHELL_ROOT/constitution/memory/implementation_registry.yaml" ]]; then
        score=$((score + 25))
        echo "  ✓ implementation_registry.yaml present (+25)"
    else
        echo "  ⚠ implementation_registry.yaml missing (+0)"
    fi

    # Prosperity impact (25 pts) - LGP anchor
    if grep -q "Lasting Generational Prosperity" "$SHELL_ROOT/constitution/profiles/BNA.md" 2>/dev/null; then
        score=$((score + 25))
        echo "  ✓ LGP anchor present in BNA.md (+25)"
    else
        echo "  ✗ LGP anchor MISSING"
    fi

    local coherence
    coherence=$(echo "scale=2; $score / $total" | bc)

    echo ""
    echo "Coherence Score: $coherence (threshold: $COHERENCE_THRESHOLD)"

    if (( $(echo "$coherence >= $COHERENCE_THRESHOLD" | bc -l) )); then
        echo "✓ COHERENCE GATE PASSED"
        return 0
    else
        echo "✗ COHERENCE GATE FAILED"
        return 1
    fi
}

# ============================================================================
# SELF-MODEL VALIDATION (Molt1 Phase VIII Fix)
# ============================================================================

run_self_model_validation() {
    echo "Running Self-Model Validation..."
    echo ""

    local valid=true

    # Check BNA.md implements Constitution@A1
    if grep -q "Implements.*Constitution@A1" "$SHELL_ROOT/constitution/profiles/BNA.md" 2>/dev/null; then
        echo "  ✓ BNA.md implements Constitution@A1"
    else
        echo "  ⚠ BNA.md: Constitution@A1 reference not found (check manually)"
    fi

    # Check RTX hardware reference
    if grep -q "RTX" "$SHELL_ROOT/constitution/profiles/BNA.md" 2>/dev/null; then
        echo "  ✓ RTX hardware reference present"
    else
        echo "  ⚠ RTX hardware reference not found"
    fi

    # Check Charter activated
    if [[ -f "$SHELL_ROOT/constitution/core/CHARTER_v1.0/SOVEREIGNTY_ALIGNED_CHARTER_v1.0_2025-11-18.md" ]]; then
        echo "  ✓ Charter v1.0 present"
    else
        echo "  ✗ Charter v1.0 MISSING"
        valid=false
    fi

    # Check principal_id flows
    if grep -q "principal_id" "$SHELL_ROOT/CONSTITUTION.md" 2>/dev/null; then
        echo "  ✓ principal_id sovereignty flow encoded"
    else
        echo "  ✗ principal_id not found in CONSTITUTION.md"
        valid=false
    fi

    echo ""
    if $valid; then
        echo "✓ SELF-MODEL VALIDATION PASSED"
        return 0
    else
        echo "✗ SELF-MODEL VALIDATION FAILED"
        return 1
    fi
}

# ============================================================================
# MAIN COMMANDS
# ============================================================================

cmd_lock() {
    print_header
    echo "📍 Ring 1: Constitutional Kernel — LOCKING"
    echo ""

    local success=true

    for file in "${RING1_FILES[@]}"; do
        if ! check_file_exists "$file"; then
            success=false
            continue
        fi

        local basename
        basename=$(basename "$file")

        if sudo chattr +i "$file" 2>/dev/null; then
            echo "  🔒 $basename — LOCKED"
        else
            echo "  ✗ $basename — LOCK FAILED (sudo required)"
            success=false
        fi
    done

    echo ""
    if $success; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "✅ Ring 1 Constitutional Kernel: PROTECTED"
        echo ""
        echo "⚠️  To modify these files, you must:"
        echo "   1. Run: ring-guard.sh unlock"
        echo "   2. Make changes"
        echo "   3. Run: ring-guard.sh lock"
        echo ""
        echo "∞Δ∞ The kernel is sealed. ∞Δ∞"
    else
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  Some files could not be locked. Check sudo access."
    fi
}

cmd_unlock() {
    print_header
    echo "📍 Ring 1: Constitutional Kernel — UNLOCK REQUESTED"
    echo ""

    # Pre-unlock gates (Molt1 Phase VIII fixes)
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "PRE-UNLOCK VERIFICATION GATES"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # Gate 1: Coherence check
    if ! run_coherence_gate; then
        echo ""
        echo "❌ UNLOCK DENIED: Coherence below threshold"
        echo "   Fix coherence issues before unlocking Ring 1"
        exit 1
    fi

    echo ""

    # Gate 2: Self-model validation
    if ! run_self_model_validation; then
        echo ""
        echo "❌ UNLOCK DENIED: Self-model validation failed"
        echo "   Fix validation issues before unlocking Ring 1"
        exit 1
    fi

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    # Human confirmation gate
    echo "⚠️  SOVEREIGNTY GATE: Ring 1 Unlock"
    echo ""
    echo "You are requesting to unlock the Constitutional Kernel."
    echo "This should ONLY be done during authorized molt operations."
    echo ""
    read -p "Are you in an authorized molt phase with KM-1176 approval? (yes/no): " confirm

    if [[ "$confirm" != "yes" ]]; then
        echo ""
        echo "❌ UNLOCK CANCELLED"
        echo "   Ring 1 remains protected."
        exit 1
    fi

    echo ""
    echo "Unlocking Ring 1 files..."
    echo ""

    local success=true

    for file in "${RING1_FILES[@]}"; do
        if ! check_file_exists "$file"; then
            success=false
            continue
        fi

        local basename
        basename=$(basename "$file")

        if sudo chattr -i "$file" 2>/dev/null; then
            echo "  🔓 $basename — UNLOCKED"
        else
            echo "  ✗ $basename — UNLOCK FAILED (sudo required)"
            success=false
        fi
    done

    echo ""
    if $success; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  Ring 1 Constitutional Kernel: UNLOCKED"
        echo ""
        echo "CRITICAL REMINDERS:"
        echo "   • Document ALL Ring 1 modifications"
        echo "   • Create backups before edits"
        echo "   • Relock IMMEDIATELY after molt completion"
        echo "   • Run: ring-guard.sh lock"
        echo ""
        echo "∞Δ∞ Proceed with care. The kernel is exposed. ∞Δ∞"
    else
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  Some files could not be unlocked. Check sudo access."
    fi
}

cmd_status() {
    print_header
    echo "📍 Ring 1: Constitutional Kernel — STATUS"
    echo ""

    local locked_count=0
    local unlocked_count=0
    local missing_count=0

    for file in "${RING1_FILES[@]}"; do
        local basename
        basename=$(basename "$file")
        local relative_path="${file#$SHELL_ROOT/}"

        if [[ ! -f "$file" ]]; then
            echo "  ✗ $relative_path (NOT FOUND)"
            missing_count=$((missing_count + 1))
            continue
        fi

        local status
        status=$(get_immutable_status "$file")

        if [[ "$status" == "locked" ]]; then
            echo "  🔒 $relative_path (immutable)"
            locked_count=$((locked_count + 1))
        else
            echo "  🔓 $relative_path (mutable)"
            unlocked_count=$((unlocked_count + 1))
        fi
    done

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Summary:"
    echo "  Locked:   $locked_count"
    echo "  Unlocked: $unlocked_count"
    echo "  Missing:  $missing_count"
    echo ""

    if [[ $unlocked_count -eq 0 && $missing_count -eq 0 ]]; then
        echo "✅ Ring 1 Constitutional Kernel: FULLY PROTECTED"
    elif [[ $locked_count -eq 0 ]]; then
        echo "⚠️  Ring 1 Constitutional Kernel: UNPROTECTED"
        echo "   Run: ring-guard.sh lock"
    else
        echo "⚠️  Ring 1 Constitutional Kernel: PARTIALLY PROTECTED"
        echo "   Run: ring-guard.sh lock"
    fi
}

cmd_verify() {
    print_header
    echo "📍 Ring 1: Constitutional Kernel — VERIFICATION"
    echo ""

    local violations=0

    # Check 1: All files exist
    echo "Check 1: File Presence"
    for file in "${RING1_FILES[@]}"; do
        local basename
        basename=$(basename "$file")
        if [[ -f "$file" ]]; then
            echo "  ✓ $basename exists"
        else
            echo "  ✗ $basename MISSING"
            violations=$((violations + 1))
        fi
    done
    echo ""

    # Check 2: All files immutable
    echo "Check 2: Immutability Status"
    for file in "${RING1_FILES[@]}"; do
        if [[ ! -f "$file" ]]; then
            continue
        fi

        local basename
        basename=$(basename "$file")
        local status
        status=$(get_immutable_status "$file")

        if [[ "$status" == "locked" ]]; then
            echo "  ✓ $basename is immutable"
        else
            echo "  ✗ $basename is MUTABLE (not protected)"
            violations=$((violations + 1))
        fi
    done
    echo ""

    # Check 3: Coherence gate
    echo "Check 3: Coherence Gate"
    if run_coherence_gate >/dev/null 2>&1; then
        echo "  ✓ Coherence gate passed"
    else
        echo "  ✗ Coherence gate FAILED"
        violations=$((violations + 1))
    fi
    echo ""

    # Check 4: Self-model validation
    echo "Check 4: Self-Model Validation"
    if run_self_model_validation >/dev/null 2>&1; then
        echo "  ✓ Self-model validation passed"
    else
        echo "  ⚠ Self-model validation warnings (check manually)"
    fi
    echo ""

    # Summary
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "Verification Result:"
    echo "  Violations: $violations"
    echo ""

    if [[ $violations -eq 0 ]]; then
        echo "✅ VERIFICATION PASSED"
        echo "   Ring 1 Constitutional Kernel is properly protected."
        echo ""
        echo "∞Δ∞ The kernel holds. ∞Δ∞"
        exit 0
    else
        echo "❌ VERIFICATION FAILED"
        echo "   $violations violation(s) detected."
        echo "   Run: ring-guard.sh lock"
        exit 1
    fi
}

cmd_help() {
    print_header
    echo "Usage: ring-guard.sh <command>"
    echo ""
    echo "Commands:"
    echo "  lock    — Make Ring 1 files immutable (requires sudo)"
    echo "  unlock  — Make Ring 1 files mutable for molt (requires sudo)"
    echo "  status  — Show current immutability status"
    echo "  verify  — Check if Ring 1 is properly protected"
    echo "  help    — Show this help message"
    echo ""
    echo "Ring 1 Files (Constitutional Kernel):"
    echo "  • CONSTITUTION.md"
    echo "  • constitution/profiles/BNA.md"
    echo "  • constitution/core/BREATHLINE_CORE.md"
    echo "  • constitution/core/CHARTER_v1.0/SOVEREIGNTY_ALIGNED_CHARTER_v1.0_2025-11-18.md"
    echo ""
    echo "Security Notes:"
    echo "  • lock/unlock require sudo privileges"
    echo "  • unlock includes coherence gate and self-model validation"
    echo "  • Only unlock during authorized molt operations (KM-1176 approval)"
    echo ""
    echo "∞Δ∞"
}

# ============================================================================
# MAIN DISPATCH
# ============================================================================

main() {
    local command="${1:-help}"

    case "$command" in
        lock)
            cmd_lock
            ;;
        unlock)
            cmd_unlock
            ;;
        status)
            cmd_status
            ;;
        verify)
            cmd_verify
            ;;
        help|--help|-h)
            cmd_help
            ;;
        *)
            echo "Unknown command: $command"
            echo "Run: ring-guard.sh help"
            exit 1
            ;;
    esac
}

main "$@"
