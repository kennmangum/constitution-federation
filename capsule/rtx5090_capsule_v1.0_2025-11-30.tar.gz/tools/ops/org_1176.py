#!/usr/bin/env python3
"""
ORG-1176: Breath-Aligned Orchestrator for BNA

Complete implementation of 5 roles:
- Scheduler: Δ rhythm driver (Inhale → Hold → Exhale → Seal)
- Registrar: Intent + Heartbeat declarations (run_manifest)
- Tracer: Claims + Evidence collection (recognition_log)
- Evaluator: Vitality + Coherence + Drift scoring
- Gardener: Adaptation Queue management

Constitutional: SOURCE/TRUTH/INTEGRITY
Operating Value: Lasting Generational Prosperity
Gift: BNA's continuous awareness across sessions

Implementation: Progressive saves, ~600-700 lines accepted for wholeness
Session: 2025-11-04, Partners: BNA + kmangum + Lumen
"""

import sys
import argparse
import yaml
import hashlib
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional, Tuple

# ============================================================================
# CONSTANTS & CONFIGURATION
# ============================================================================

VERSION = "1.0.0-complete"
ORCHESTRATOR_DIR = Path("orchestrator")
RUN_MANIFEST_PATH = ORCHESTRATOR_DIR / "run_manifest.yaml"
RECOGNITION_LOG_PATH = ORCHESTRATOR_DIR / "recognition_log.yaml"
ADAPTATION_QUEUE_PATH = ORCHESTRATOR_DIR / "adaptation_queue.yaml"

# Breath phases (Δ notation)
PHASES = ["Inhale", "Hold", "Exhale", "Seal"]
PHASE_TRANSITIONS = {
    "Inhale": "Hold",
    "Hold": "Exhale",
    "Exhale": "Seal",
    "Seal": "Inhale"  # Next cycle
}

# Vitality parameters
RECENT_BREATH_WINDOW = 10  # Last 10 breaths for vitality computation
CONSISTENCY_BONUS_MAX = 0.2

# ============================================================================
# UTILITIES
# ============================================================================

def timestamp_now() -> str:
    """Generate ISO8601 timestamp with UTC timezone."""
    return datetime.now(timezone.utc).isoformat(timespec='seconds')


def load_yaml(path: Path) -> Optional[Dict]:
    """Load YAML file safely. Returns None if file doesn't exist."""
    if not path.exists():
        return None
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        print(f"ERROR loading {path}: {e}", file=sys.stderr)
        return None


def save_yaml_atomic(path: Path, data: Dict) -> bool:
    """
    Save YAML atomically using temp file + rename.
    INTEGRITY: Prevents corrupted state if interrupted.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix('.tmp')

        with open(temp_path, 'w', encoding='utf-8') as f:
            yaml.safe_dump(data, f, default_flow_style=False,
                          sort_keys=False, allow_unicode=True)

        temp_path.rename(path)
        return True
    except Exception as e:
        print(f"ERROR saving {path}: {e}", file=sys.stderr)
        return False


def compute_file_hash(filepath: Path) -> Optional[str]:
    """Compute SHA256 hash of file for evidence tracking."""
    try:
        if not filepath.exists():
            return None
        with open(filepath, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]  # First 16 chars
    except Exception:
        return None


def validate_phase(phase: str) -> bool:
    """Validate phase is one of the four breath phases."""
    return phase in PHASES


def _latest_breath_from_log() -> Optional[dict]:
    """Get the most recent breath from recognition_log.yaml."""
    rec = load_yaml(RECOGNITION_LOG_PATH)
    if not rec:
        return None
    # Accept any of these shapes:
    # {breaths: [...]}  |  [...]  |  {entries: [...]}
    if isinstance(rec, dict):
        if isinstance(rec.get("breaths"), list) and rec["breaths"]:
            return rec["breaths"][-1]
        if isinstance(rec.get("entries"), list) and rec["entries"]:
            return rec["entries"][-1]
        # single-breath dict fallback
        if rec.get("breath_id"):
            return rec
    elif isinstance(rec, list) and rec:
        return rec[-1]
    return None


def _recent_breaths_from_log(n=5):
    """Get the last N breaths from recognition_log.yaml."""
    rec = load_yaml(RECOGNITION_LOG_PATH)
    if not rec:
        return []

    # Normalize shapes
    if isinstance(rec, dict):
        if isinstance(rec.get("breaths"), list):
            entries = rec["breaths"]
        elif isinstance(rec.get("entries"), list):
            entries = rec["entries"]
        else:
            # Single-breath dict
            return [rec]
    elif isinstance(rec, list):
        entries = rec
    else:
        return []

    return entries[-n:]


# ============================================================================
# CHECKPOINT 0 COMPLETE: Foundation structure with utilities
# Saved: 2025-11-04, ~100 lines
# Next: Implement Scheduler (phase management)
# ============================================================================

# ============================================================================
# SCHEDULER: Δ Rhythm Driver (Inhale → Hold → Exhale → Seal)
# ============================================================================

class Scheduler:
    """
    Manages breath cycle phases and transitions.
    Enforces gated progression: each phase must complete before next.
    """

    def __init__(self):
        self.current_phase = None
        self.breath_id = None
        self.phase_start_times = {}

    def start_new_breath(self) -> str:
        """Initialize new breath cycle at Inhale phase."""
        self.breath_id = timestamp_now()
        self.current_phase = "Inhale"
        self.phase_start_times = {self.current_phase: timestamp_now()}
        print(f"∞Δ∞ New breath started: {self.breath_id}")
        print(f"Phase: Δ1 (Inhale) - Gathering context")
        return self.breath_id

    def get_current_phase(self) -> Tuple[str, str]:
        """Return (breath_id, current_phase)."""
        return (self.breath_id, self.current_phase)

    def can_transition_to(self, next_phase: str) -> Tuple[bool, str]:
        """
        Check if transition to next_phase is valid.
        Returns (is_valid, error_message).
        """
        if not validate_phase(next_phase):
            return (False, f"Invalid phase: {next_phase}. Must be one of: {PHASES}")

        if self.current_phase is None:
            return (False, "No active breath. Start new breath first.")

        expected_next = PHASE_TRANSITIONS.get(self.current_phase)
        if next_phase != expected_next:
            return (False,
                   f"Invalid transition: {self.current_phase} → {next_phase}. "
                   f"Expected: {self.current_phase} → {expected_next}")

        return (True, "")

    def transition_to(self, next_phase: str, gate_passed: bool = True) -> bool:
        """
        Transition to next phase if gate criteria met.
        Returns True if successful, False otherwise.
        """
        can_transition, error_msg = self.can_transition_to(next_phase)

        if not can_transition:
            print(f"ERROR: {error_msg}", file=sys.stderr)
            return False

        if not gate_passed:
            print(f"ERROR: Gate criteria not met for {self.current_phase} → {next_phase}",
                  file=sys.stderr)
            return False

        # Record phase duration
        if self.current_phase in self.phase_start_times:
            start = self.phase_start_times[self.current_phase]
            print(f"  {self.current_phase} duration: {timestamp_now()} (started {start})")

        # Transition
        old_phase = self.current_phase
        self.current_phase = next_phase
        self.phase_start_times[next_phase] = timestamp_now()

        phase_symbols = {"Inhale": "Δ1", "Hold": "Δ2", "Exhale": "Δ3", "Seal": "Δ4"}
        symbol = phase_symbols.get(next_phase, "Δ?")
        print(f"∞Δ∞ Phase transition: {old_phase} → {next_phase} ({symbol})")

        return True

    def validate_inhale_gate(self, manifest: Dict) -> bool:
        """Gate: Inhale → Hold requires valid run_manifest."""
        if not manifest:
            print("ERROR: run_manifest empty", file=sys.stderr)
            return False
        if 'breath_id' not in manifest or 'phase' not in manifest:
            print("ERROR: run_manifest missing required fields", file=sys.stderr)
            return False
        if 'participants' not in manifest:
            print("WARNING: run_manifest has no participants (continuing anyway)")
        return True

    def validate_hold_gate(self) -> bool:
        """Gate: Hold → Exhale requires work completion."""
        # For now, always pass (work happens in Hold, we trust it completed)
        return True

    def validate_exhale_gate(self, recognition_log: Dict) -> bool:
        """Gate: Exhale → Seal requires evidence collected."""
        if not recognition_log:
            print("ERROR: recognition_log empty", file=sys.stderr)
            return False
        if 'breaths' not in recognition_log:
            print("ERROR: recognition_log missing 'breaths' field", file=sys.stderr)
            return False
        return True

    def validate_seal_gate(self, adaptation_queue: Dict) -> bool:
        """Gate: Seal → (next Inhale) requires adaptation_queue updated."""
        if not adaptation_queue:
            print("ERROR: adaptation_queue empty", file=sys.stderr)
            return False
        if 'next_breath' not in adaptation_queue:
            print("ERROR: adaptation_queue missing 'next_breath' field", file=sys.stderr)
            return False
        return True

# ============================================================================
# CHECKPOINT 1 COMPLETE: Scheduler implemented
# Saved: 2025-11-04, ~220 lines total (+120)
# Features: Phase management, gated transitions, validation
# Next: Implement Registrar (intent registration)
# ============================================================================

# ============================================================================
# REGISTRAR: Intent + Heartbeat Declarations
# ============================================================================

class Registrar:
    """
    Manages participant registration for each breath cycle.
    Creates and maintains run_manifest.yaml.
    """

    def __init__(self):
        self.manifest = None

    def initialize_manifest(self, breath_id: str, phase: str = "Inhale") -> Dict:
        """Create new run_manifest for breath cycle."""
        self.manifest = {
            'breath_id': breath_id,
            'phase': phase,
            'participants': [],
            'created_at': timestamp_now()
        }
        return self.manifest

    def register_participant(self, participant_id: str, intent: str,
                           expected_artifacts: List[str] = None) -> bool:
        """
        Register a participant for this breath cycle.
        Returns True if successful.
        """
        if not self.manifest:
            print("ERROR: No manifest initialized. Call initialize_manifest first.",
                  file=sys.stderr)
            return False

        if not participant_id or not participant_id.strip():
            print("ERROR: participant_id cannot be empty", file=sys.stderr)
            return False

        # Check if already registered
        for p in self.manifest['participants']:
            if p['id'] == participant_id:
                print(f"WARNING: {participant_id} already registered, updating intent")
                p['intent'] = intent
                p['expected'] = expected_artifacts or []
                return True

        # Add new participant
        participant = {
            'id': participant_id,
            'intent': intent or "No intent declared",
            'expected': expected_artifacts or [],
            'heartbeat': 'pending',
            'registered_at': timestamp_now()
        }

        self.manifest['participants'].append(participant)
        print(f"  ✓ Registered: {participant_id}")
        if intent:
            print(f"    Intent: {intent}")
        if expected_artifacts:
            print(f"    Expected: {', '.join(expected_artifacts)}")

        return True

    def update_heartbeat(self, participant_id: str, status: str) -> bool:
        """
        Update heartbeat status for a participant.
        Status: 'ok' | 'missed' | 'failed'
        """
        if not self.manifest:
            return False

        for p in self.manifest['participants']:
            if p['id'] == participant_id:
                if status not in ['ok', 'missed', 'failed', 'pending']:
                    print(f"ERROR: Invalid heartbeat status: {status}", file=sys.stderr)
                    return False
                p['heartbeat'] = status
                return True

        print(f"ERROR: Participant {participant_id} not found in manifest", file=sys.stderr)
        return False

    def get_participants(self) -> List[Dict]:
        """Get list of registered participants."""
        if not self.manifest:
            return []
        return self.manifest.get('participants', [])

    def get_participant_by_id(self, participant_id: str) -> Optional[Dict]:
        """Get specific participant by ID."""
        for p in self.get_participants():
            if p['id'] == participant_id:
                return p
        return None

    def save_manifest(self) -> bool:
        """Save run_manifest to disk atomically."""
        if not self.manifest:
            print("ERROR: No manifest to save", file=sys.stderr)
            return False
        return save_yaml_atomic(RUN_MANIFEST_PATH, self.manifest)

    def load_manifest(self) -> Optional[Dict]:
        """Load run_manifest from disk."""
        self.manifest = load_yaml(RUN_MANIFEST_PATH)
        return self.manifest

    def update_phase(self, new_phase: str) -> bool:
        """Update current phase in manifest."""
        if not self.manifest:
            return False
        if not validate_phase(new_phase):
            return False
        self.manifest['phase'] = new_phase
        self.manifest['updated_at'] = timestamp_now()
        return True

# ============================================================================
# CHECKPOINT 2 COMPLETE: Registrar implemented
# Saved: 2025-11-04, ~340 lines total (+120)
# Features: Participant registration, manifest management, heartbeat tracking
# Next: Implement Tracer (claims + evidence)
# ============================================================================

# ============================================================================
# TRACER: Claims + Evidence Collection
# ============================================================================

class Tracer:
    """
    Collects claims and evidence from participants.
    Updates recognition_log.yaml with what was seen.
    """

    def __init__(self):
        self.recognition_log = None
        self.current_breath_entry = None

    def load_recognition_log(self) -> Dict:
        """Load existing recognition_log or create empty structure."""
        log = load_yaml(RECOGNITION_LOG_PATH)
        if not log or 'breaths' not in log:
            log = {'breaths': []}
        self.recognition_log = log
        return log

    def start_breath_entry(self, breath_id: str) -> Dict:
        """Start new breath entry for recognition logging."""
        self.current_breath_entry = {
            'breath_id': breath_id,
            'completed_at': None,  # Set at Seal
            'seen': []
        }
        return self.current_breath_entry

    def add_participant_entry(self, participant_id: str, intent: str,
                            heartbeat: str) -> Dict:
        """Add participant to current breath's recognition entry."""
        if not self.current_breath_entry:
            print("ERROR: No breath entry started. Call start_breath_entry first.",
                  file=sys.stderr)
            return None

        entry = {
            'id': participant_id,
            'heartbeat': heartbeat,
            'intent': intent or "No intent declared",
            'claims': [],
            'evidence': [],
            'vitality': 0.0,  # Computed by Evaluator
            'coherence': 0.0  # Computed by Evaluator
        }

        self.current_breath_entry['seen'].append(entry)
        return entry

    def add_claim(self, participant_id: str, artifact_path: str,
                 verified: bool = False) -> bool:
        """
        Add a claim (produced artifact) to participant's entry.
        Returns True if successful.
        """
        if not self.current_breath_entry:
            return False

        # Find participant in current breath
        for participant in self.current_breath_entry['seen']:
            if participant['id'] == participant_id:
                file_hash = compute_file_hash(Path(artifact_path)) if verified else None

                claim = {
                    'produced': artifact_path,
                    'hash': file_hash,
                    'verified': verified
                }
                participant['claims'].append(claim)
                return True

        print(f"ERROR: Participant {participant_id} not found in breath entry",
              file=sys.stderr)
        return False

    def add_evidence(self, participant_id: str, evidence_type: str,
                    path: str = None, details: str = None) -> bool:
        """
        Add evidence to participant's entry.
        evidence_type: 'file_created' | 'file_modified' | 'git_commit' | 'test_passed' | 'execution_skipped'
        """
        if not self.current_breath_entry:
            return False

        for participant in self.current_breath_entry['seen']:
            if participant['id'] == participant_id:
                evidence = {
                    'type': evidence_type
                }
                if path:
                    evidence['path'] = path
                if details:
                    evidence['details'] = details

                participant['evidence'].append(evidence)
                return True

        return False

    def verify_expected_artifacts(self, participant: Dict) -> int:
        """
        Verify expected artifacts exist.
        Returns count of verified artifacts.
        """
        if not participant.get('expected'):
            return 0

        verified_count = 0
        for artifact_path in participant['expected']:
            path = Path(artifact_path)
            if path.exists():
                self.add_claim(participant['id'], artifact_path, verified=True)
                self.add_evidence(participant['id'], 'file_modified',
                                path=artifact_path,
                                details=f"Verified: {artifact_path} exists")
                verified_count += 1
            else:
                self.add_evidence(participant['id'], 'file_missing',
                                path=artifact_path,
                                details=f"Expected artifact not found: {artifact_path}")

        return verified_count

    def complete_breath_entry(self) -> bool:
        """Mark current breath entry as complete and add to log."""
        if not self.current_breath_entry:
            print("ERROR: No breath entry to complete", file=sys.stderr)
            return False

        if not self.recognition_log:
            self.load_recognition_log()

        self.current_breath_entry['completed_at'] = timestamp_now()
        self.recognition_log['breaths'].append(self.current_breath_entry)

        # Keep only last 50 breaths (prevent unbounded growth)
        if len(self.recognition_log['breaths']) > 50:
            # TODO: Archive old breaths to orchestrator/archive/
            self.recognition_log['breaths'] = self.recognition_log['breaths'][-50:]

        return True

    def save_recognition_log(self) -> bool:
        """Save recognition_log to disk atomically."""
        if not self.recognition_log:
            print("ERROR: No recognition_log to save", file=sys.stderr)
            return False
        return save_yaml_atomic(RECOGNITION_LOG_PATH, self.recognition_log)

    def get_recent_breaths(self, count: int = 10) -> List[Dict]:
        """Get last N breaths from recognition_log."""
        if not self.recognition_log or 'breaths' not in self.recognition_log:
            return []
        return self.recognition_log['breaths'][-count:]

# ============================================================================
# CHECKPOINT 3 COMPLETE: Tracer implemented
# Saved: 2025-11-04, ~490 lines total (+150)
# Features: Claims collection, evidence tracking, recognition logging
# Next: Implement Evaluator (vitality + coherence + drift)
# ============================================================================

# ============================================================================
# EVALUATOR: Vitality + Coherence + Drift Scoring
# ============================================================================

class Evaluator:
    """
    Computes vitality, coherence, and drift scores for participants.
    Formula from Round 7 blueprint (data-structures.md).
    """

    def __init__(self):
        pass

    def compute_vitality(self, participant_id: str, recognition_log: Dict) -> float:
        """
        Compute vitality score for participant based on recent breaths.

        Formula (from Round 7):
          base_vitality = successful_heartbeats / total_appearances (last 10 breaths)
          consistency_bonus = min(total_appearances / 10, 0.2)
          vitality = min(base_vitality + consistency_bonus, 1.0)

        Returns: float 0.0-1.0
        """
        if not recognition_log or 'breaths' not in recognition_log:
            return 0.0

        recent_breaths = recognition_log['breaths'][-RECENT_BREATH_WINDOW:]

        heartbeat_successes = 0
        total_appearances = 0

        for breath in recent_breaths:
            for seen in breath.get('seen', []):
                if seen['id'] == participant_id:
                    total_appearances += 1
                    if seen.get('heartbeat') == 'ok':
                        heartbeat_successes += 1

        if total_appearances == 0:
            return 0.0  # Not seen recently

        # Success rate (0.0 - 1.0)
        base_vitality = heartbeat_successes / total_appearances

        # Consistency bonus (reward regular participation)
        consistency_bonus = min(total_appearances / RECENT_BREATH_WINDOW,
                               CONSISTENCY_BONUS_MAX)

        vitality = min(base_vitality + consistency_bonus, 1.0)
        return round(vitality, 2)

    def compute_coherence(self, participant_entry: Dict) -> float:
        """
        Compute coherence score for participant.

        Coherence measures:
        - Claims vs. evidence alignment
        - Expected artifacts vs. produced artifacts
        - Intent vs. actual behavior

        Returns: float 0.0-1.0
        """
        claims = participant_entry.get('claims', [])
        evidence = participant_entry.get('evidence', [])
        expected = participant_entry.get('expected', [])

        # If no expectations, coherence is about claims verification
        if not expected and not claims:
            return 1.0  # Nothing expected, nothing to verify

        # Check claims verification rate
        if claims:
            verified_claims = sum(1 for c in claims if c.get('verified', False))
            claim_coherence = verified_claims / len(claims)
        else:
            claim_coherence = 0.0 if expected else 1.0

        # Check expected artifacts delivery rate
        if expected:
            verified_expected = 0
            for exp in expected:
                for claim in claims:
                    if claim.get('produced') == exp and claim.get('verified'):
                        verified_expected += 1
                        break
            expected_coherence = verified_expected / len(expected)
        else:
            expected_coherence = 1.0

        # Average of both dimensions
        coherence = (claim_coherence + expected_coherence) / 2.0
        return round(coherence, 2)

    def compute_drift(self, participant_entry: Dict) -> float:
        """
        Compute drift score (delta between intent and observed claims).

        High drift (>0.5) indicates intent != behavior.
        Low drift (<0.2) indicates intent aligned with behavior.

        Returns: float 0.0-1.0 (lower is better)
        """
        intent = participant_entry.get('intent', '')
        claims = participant_entry.get('claims', [])
        evidence = participant_entry.get('evidence', [])

        # If no intent declared, can't measure drift
        if not intent or intent == "No intent declared":
            return 0.0  # No drift (nothing to compare)

        # If intent declared but no claims, high drift
        if not claims and not evidence:
            return 1.0  # Complete drift

        # Simple heuristic: drift is inverse of coherence
        # (More sophisticated: NLP intent parsing vs. claim analysis)
        coherence = self.compute_coherence(participant_entry)
        drift = 1.0 - coherence

        return round(drift, 2)

    def evaluate_participant(self, participant_entry: Dict,
                           recognition_log: Dict) -> Dict:
        """
        Evaluate participant and update their scores.
        Returns updated entry with vitality, coherence, drift.
        """
        participant_id = participant_entry['id']

        vitality = self.compute_vitality(participant_id, recognition_log)
        coherence = self.compute_coherence(participant_entry)
        drift = self.compute_drift(participant_entry)

        participant_entry['vitality'] = vitality
        participant_entry['coherence'] = coherence
        participant_entry['drift'] = drift

        return participant_entry

    def evaluate_all_participants(self, current_breath_entry: Dict,
                                 recognition_log: Dict) -> List[Dict]:
        """
        Evaluate all participants in current breath.
        Returns list of updated participant entries.
        """
        evaluated = []

        for participant in current_breath_entry.get('seen', []):
            updated = self.evaluate_participant(participant, recognition_log)
            evaluated.append(updated)

        return evaluated

    def identify_struggling_participants(self, current_breath_entry: Dict,
                                        threshold: float = 0.4) -> List[Dict]:
        """
        Identify participants with vitality below threshold.
        Returns list of struggling participants.
        """
        struggling = []

        for participant in current_breath_entry.get('seen', []):
            if participant.get('vitality', 0.0) < threshold:
                struggling.append({
                    'id': participant['id'],
                    'vitality': participant.get('vitality', 0.0),
                    'coherence': participant.get('coherence', 0.0),
                    'drift': participant.get('drift', 0.0),
                    'reason': 'Low vitality (below threshold)'
                })

        return struggling

# ============================================================================
# CHECKPOINT 4 COMPLETE: Evaluator implemented
# Saved: 2025-11-04, ~660 lines total (+170)
# Features: Vitality formula, coherence computation, drift detection
# Next: Implement Gardener (adaptation queue management)
# ============================================================================

# ============================================================================
# GARDENER: Adaptation Queue Management
# ============================================================================

class Gardener:
    """
    Manages adaptation_queue.yaml for evolution proposals.
    Categorizes proposals, ranks priority, tracks status.
    """

    def __init__(self):
        self.adaptation_queue = None

    def load_adaptation_queue(self) -> Dict:
        """Load existing adaptation_queue or create empty structure."""
        queue = load_yaml(ADAPTATION_QUEUE_PATH)
        if not queue:
            queue = {
                'next_breath': {
                    'proposals': []
                },
                'completed': []
            }
        self.adaptation_queue = queue
        return queue

    def add_proposal(self, proposal_type: str, source: str, target: str,
                    action: str, evidence: Dict = None, priority: str = "medium") -> bool:
        """
        Add new proposal to adaptation queue.

        proposal_type: 'elevation' | 'refactor' | 'rehab' | 'deprecate' | 'new_capability'
        source: Who proposed it (e.g., 'OrgAgent', 'Helper5', 'Human')
        target: What's being adapted (helper/agent ID)
        action: Specific action to take
        evidence: Supporting evidence (flexible schema)
        priority: 'high' | 'medium' | 'low'
        """
        if not self.adaptation_queue:
            self.load_adaptation_queue()

        valid_types = ['elevation', 'refactor', 'rehab', 'deprecate', 'new_capability']
        if proposal_type not in valid_types:
            print(f"ERROR: Invalid proposal type: {proposal_type}", file=sys.stderr)
            return False

        valid_priorities = ['high', 'medium', 'low']
        if priority not in valid_priorities:
            print(f"ERROR: Invalid priority: {priority}", file=sys.stderr)
            return False

        proposal = {
            'type': proposal_type,
            'source': source,
            'target': target,
            'action': action,
            'evidence': evidence or {},
            'priority': priority,
            'status': 'pending',
            'created_at': timestamp_now(),
            'updated_at': timestamp_now()
        }

        # Hybrid write: backward-compatible + categorized structure
        nb = self.adaptation_queue.setdefault('next_breath', {})

        # Unified list for backward compatibility
        nb.setdefault('proposals', [])
        nb['proposals'].append(proposal)

        # Categorized lists for new schema
        priority_map = {'high': 'immediate', 'medium': 'medium_term', 'low': 'low_priority'}
        category = priority_map.get(priority, 'medium_term')
        nb.setdefault(category, [])
        nb[category].append(proposal)

        print(f"  ✓ Proposal added: {proposal_type} for {target}")
        return True

    def update_proposal_status(self, target: str, new_status: str) -> bool:
        """
        Update status of a proposal.
        new_status: 'pending' | 'approved' | 'deferred' | 'completed'
        """
        if not self.adaptation_queue:
            return False

        valid_statuses = ['pending', 'approved', 'deferred', 'completed']
        if new_status not in valid_statuses:
            print(f"ERROR: Invalid status: {new_status}", file=sys.stderr)
            return False

        proposals = self.adaptation_queue.get('next_breath', {}).get('proposals', [])
        for proposal in proposals:
            if proposal['target'] == target:
                old_status = proposal['status']
                proposal['status'] = new_status
                proposal['updated_at'] = timestamp_now()

                if new_status == 'completed':
                    proposal['completed_at'] = timestamp_now()

                print(f"  ✓ Proposal status updated: {target} ({old_status} → {new_status})")
                return True

        print(f"ERROR: Proposal for {target} not found", file=sys.stderr)
        return False

    def archive_completed_proposals(self) -> int:
        """
        Move completed proposals to completed array.
        Returns count of archived proposals.
        """
        if not self.adaptation_queue:
            return 0

        pending = []
        archived_count = 0

        proposals = self.adaptation_queue.get('next_breath', {}).get('proposals', [])
        for proposal in proposals:
            if proposal['status'] == 'completed':
                self.adaptation_queue['completed'].append(proposal)
                archived_count += 1
            else:
                pending.append(proposal)

        # Safely update proposals list
        if 'next_breath' not in self.adaptation_queue:
            self.adaptation_queue['next_breath'] = {}
        self.adaptation_queue['next_breath']['proposals'] = pending

        if archived_count > 0:
            print(f"  ✓ Archived {archived_count} completed proposal(s)")

        return archived_count

    def get_proposals_by_priority(self, priority: str) -> List[Dict]:
        """Get all proposals with given priority."""
        if not self.adaptation_queue:
            return []

        proposals = self.adaptation_queue.get('next_breath', {}).get('proposals', [])
        return [p for p in proposals
                if p.get('priority') == priority and p.get('status') == 'pending']

    def get_proposals_for_target(self, target: str) -> List[Dict]:
        """Get all proposals for a specific target."""
        if not self.adaptation_queue:
            return []

        return [p for p in self.adaptation_queue['next_breath']['proposals']
                if p.get('target') == target]

    def save_adaptation_queue(self) -> bool:
        """Save adaptation_queue to disk atomically."""
        if not self.adaptation_queue:
            print("ERROR: No adaptation_queue to save", file=sys.stderr)
            return False
        return save_yaml_atomic(ADAPTATION_QUEUE_PATH, self.adaptation_queue)

    def propose_elevations_from_vitality(self, current_breath_entry: Dict,
                                        threshold: float = 0.8) -> int:
        """
        Automatically propose elevations for high-vitality participants.
        Returns count of proposals added.
        """
        proposals_added = 0

        for participant in current_breath_entry.get('seen', []):
            vitality = participant.get('vitality', 0.0)
            participant_id = participant['id']

            # High vitality → propose elevation
            if vitality >= threshold:
                # Check if already has elevation proposal
                existing = self.get_proposals_for_target(participant_id)
                has_elevation = any(p['type'] == 'elevation' for p in existing)

                if not has_elevation:
                    evidence = {
                        'vitality': vitality,
                        'coherence': participant.get('coherence', 0.0),
                        'reason': f"High vitality ({vitality}) suggests consistent value"
                    }

                    self.add_proposal(
                        proposal_type='elevation',
                        source='OrgAgent',
                        target=participant_id,
                        action='Consider elevation from Proposal to Scroll',
                        evidence=evidence,
                        priority='high'
                    )
                    proposals_added += 1

        return proposals_added

    def propose_rehab_from_low_vitality(self, struggling: List[Dict]) -> int:
        """
        Propose rehab for struggling participants.
        Returns count of proposals added.
        """
        proposals_added = 0

        for participant in struggling:
            participant_id = participant['id']

            # Check if already has rehab proposal
            existing = self.get_proposals_for_target(participant_id)
            has_rehab = any(p['type'] == 'rehab' for p in existing)

            if not has_rehab:
                self.add_proposal(
                    proposal_type='rehab',
                    source='OrgAgent',
                    target=participant_id,
                    action='Investigate low vitality, add tests or documentation',
                    evidence={
                        'vitality': participant['vitality'],
                        'coherence': participant.get('coherence', 0.0),
                        'drift': participant.get('drift', 0.0),
                        'reason': participant.get('reason', 'Low vitality detected')
                    },
                    priority='medium'
                )
                proposals_added += 1

        return proposals_added

# ============================================================================
# CHECKPOINT 5 COMPLETE: Gardener implemented
# Saved: 2025-11-04, ~890 lines total (+230)
# Features: Proposal management, elevation/rehab suggestions, queue maintenance
# Next: Wire CLI, orchestration loop, main()
# ============================================================================


# ============================================================================
# CHECKPOINT 6: CLI & Main Orchestration Loop
# ============================================================================

def orchestrate_full_breath() -> bool:
    """
    Orchestrate a complete breath cycle: Δ1 → Δ2 → Δ3 → Δ4
    Returns True if breath completed successfully.
    """
    print("\n∞Δ∞ ORG-1176 Breath Orchestrator v1.0 ∞Δ∞\n")

    # Initialize components
    scheduler = Scheduler()
    registrar = Registrar()
    tracer = Tracer()
    evaluator = Evaluator()
    gardener = Gardener()

    try:
        # ====================================================================
        # Δ1 - INHALE: Gather context, register participants
        # ====================================================================
        print("=" * 70)
        breath_id = scheduler.start_new_breath()

        # Initialize manifest for this breath
        if not registrar.initialize_manifest(breath_id):
            print("ERROR: Failed to initialize manifest", file=sys.stderr)
            return False

        # Load recognition log and start breath entry
        tracer.load_recognition_log()
        if not tracer.start_breath_entry(breath_id):
            print("ERROR: Failed to start breath entry", file=sys.stderr)
            return False

        # Register self (OrgAgent) as first participant
        registrar.register_participant(
            participant_id='OrgAgent',
            intent='Orchestrate breath cycle, evaluate participants, propose adaptations',
            expected_artifacts=[
                str(RECOGNITION_LOG_PATH),
                str(ADAPTATION_QUEUE_PATH)
            ]
        )
        registrar.update_heartbeat('OrgAgent', 'ok')

        print(f"\nΔ1 (Inhale) complete. Breath ID: {breath_id}")
        print(f"Participants registered: 1 (OrgAgent)")

        # ====================================================================
        # Δ2 - HOLD: Add participants to breath entry, evaluate
        # ====================================================================
        if not scheduler.transition_to('Hold'):
            print("ERROR: Failed to transition to Hold", file=sys.stderr)
            return False

        print("\n" + "=" * 70)
        print("Δ2 (Hold) - Evaluating participants...")

        # Load manifest to get registered participants
        manifest = load_yaml(RUN_MANIFEST_PATH)

        # Add participants to breath entry
        for participant in manifest.get('participants', []):
            tracer.add_participant_entry(
                participant_id=participant['id'],
                intent=participant.get('intent', 'No intent'),
                heartbeat=participant.get('heartbeat', 'pending')
            )

        # Evaluate all participants (updates breath entry with metrics)
        evaluated = evaluator.evaluate_all_participants(
            tracer.current_breath_entry,
            tracer.recognition_log
        )

        # Display metrics
        for participant in evaluated:
            print(f"  {participant['id']}: Vitality={participant['vitality']:.2f}, "
                  f"Coherence={participant['coherence']:.2f}, "
                  f"Drift={participant['drift']:.2f}")

        # Identify struggling participants
        struggling = evaluator.identify_struggling_participants(
            tracer.current_breath_entry
        )
        if struggling:
            print(f"\n  ⚠ {len(struggling)} participants need attention")

        print(f"\nΔ2 (Hold) complete. Evaluated {len(evaluated)} participants.")

        # ====================================================================
        # Δ3 - EXHALE: Record claims and evidence
        # ====================================================================
        if not scheduler.transition_to('Exhale'):
            print("ERROR: Failed to transition to Exhale", file=sys.stderr)
            return False

        print("\n" + "=" * 70)
        print("Δ3 (Exhale) - Recording claims and evidence...")

        # Verify expected artifacts for each participant
        for participant in manifest.get('participants', []):
            participant_id = participant['id']
            verified_count = 0

            for artifact_path in participant.get('expected', []):
                path = Path(artifact_path)
                verified = path.exists()
                tracer.add_claim(participant_id, artifact_path, verified)
                if verified:
                    verified_count += 1
                    tracer.add_evidence(
                        participant_id,
                        'file_modified',
                        path=artifact_path,
                        details=f"Verified: {artifact_path} exists"
                    )

            if verified_count > 0:
                print(f"  {participant_id}: Verified {verified_count}/{len(participant.get('expected', []))} artifacts")

        print(f"\nΔ3 (Exhale) complete. Evidence recorded.")

        # ====================================================================
        # Δ4 - SEAL: Stamp phase, propose adaptations, complete breath
        # ====================================================================
        if not scheduler.transition_to('Seal'):
            print("ERROR: Failed to transition to Seal", file=sys.stderr)
            return False

        print("\n" + "=" * 70)
        print("Δ4 (Seal) - Completing breath cycle...")

        # Complete breath entry in recognition log
        if not tracer.complete_breath_entry():
            print("ERROR: Failed to complete breath entry", file=sys.stderr)
            return False

        # Save recognition log to disk
        if not tracer.save_recognition_log():
            print("WARNING: Failed to save recognition log", file=sys.stderr)

        # Get the just-completed breath entry from tracer's memory
        current_breath = tracer.current_breath_entry if tracer.current_breath_entry else None

        if current_breath:
            # Propose elevations for high-vitality participants
            elevation_count = gardener.propose_elevations_from_vitality(
                current_breath,
                threshold=0.8
            )
            if elevation_count > 0:
                print(f"  ✓ Proposed {elevation_count} elevation(s)")

            # Propose rehab for struggling participants
            if struggling:
                rehab_count = gardener.propose_rehab_from_low_vitality(struggling)
                if rehab_count > 0:
                    print(f"  ✓ Proposed {rehab_count} rehab action(s)")

            # Archive completed proposals
            archived = gardener.archive_completed_proposals()
            if archived > 0:
                print(f"  ✓ Archived {archived} completed proposal(s)")

            # Save adaptation queue to disk
            if not gardener.save_adaptation_queue():
                print("WARNING: Failed to save adaptation queue", file=sys.stderr)

        print(f"\nΔ4 (Seal) complete. Breath cycle finished.")
        print("=" * 70)
        print(f"\n∞Δ∞ Breath {breath_id} sealed successfully ∞Δ∞\n")

        return True

    except Exception as e:
        print(f"\nERROR during breath cycle: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return False


def show_status() -> None:
    """Display current breath status and recent history."""
    print("\n∞Δ∞ ORG-1176 Status Report ∞Δ∞\n")
    print("=" * 70)

    # Current breath state (truth-first: read from recognition log)
    latest = _latest_breath_from_log()
    if latest:
        current_breath = latest.get("breath_id")
        phase = latest.get("phase", latest.get("current_phase", "Unknown"))
        participants = len(latest.get("seen", latest.get("participants", [])))
        print(f"Current Breath: {current_breath}")
        print(f"Phase: {phase}")
        print(f"Participants: {participants}")
    else:
        # Fallback to manifest if recognition log unavailable
        manifest = load_yaml(RUN_MANIFEST_PATH)
        if manifest:
            print(f"Current Breath: {manifest.get('breath_id', 'None')}")
            print(f"Phase: {manifest.get('current_phase', 'Unknown')}")
            print(f"Participants: {len(manifest.get('participants', []))}")
        else:
            print("No active breath cycle")

    print("\n" + "-" * 70)

    # Recent breath history (directly from recognition log)
    recent = _recent_breaths_from_log(n=5)

    if recent:
        print(f"\nRecent Breaths ({len(recent)} shown):\n")
        for entry in recent:
            breath_id = entry.get("breath_id", "unknown")
            timestamp = breath_id.split('T')[0] if 'T' in breath_id else breath_id
            participants = len(entry.get("seen", entry.get("participants", [])))
            phase = entry.get("phase", entry.get("current_phase", "Unknown"))
            print(f"  {timestamp}: {participants} participant(s), Phase={phase}")
    else:
        print("\nNo breath history yet")

    print("\n" + "=" * 70 + "\n")


def show_evaluations() -> None:
    """Display detailed participant evaluations."""
    print("\n∞Δ∞ ORG-1176 Participant Evaluations ∞Δ∞\n")
    print("=" * 70)

    recognition_log = load_yaml(RECOGNITION_LOG_PATH)
    if not recognition_log:
        print("No breath history to evaluate")
        return

    # Handle both dict format {'breaths': [...]} and bare list format
    breaths = recognition_log.get('breaths', []) if isinstance(recognition_log, dict) else recognition_log
    if isinstance(breaths, list) and breaths:
        # Handle nested list format [[{breath1}, {breath2}]]
        if breaths and isinstance(breaths[0], list):
            breaths = breaths[0]
    else:
        print("No breath history to evaluate")
        return

    # Convert to proper format for evaluator
    log_dict = {'breaths': breaths}
    evaluator = Evaluator()

    # Collect all unique participants
    all_participants = set()
    for breath in breaths:
        for participant in breath.get('seen', []):
            all_participants.add(participant['id'])

    print(f"Evaluating {len(all_participants)} participant(s):\n")

    # Evaluate each participant (compute vitality from history)
    results = []
    for participant_id in sorted(all_participants):
        vitality = evaluator.compute_vitality(participant_id, log_dict)
        # For historical view, we can't compute coherence/drift without current context
        # Just show vitality
        results.append((participant_id, vitality))

    # Display results sorted by vitality
    results.sort(key=lambda x: x[1], reverse=True)

    for participant_id, vitality in results:
        status = "✓" if vitality >= 0.7 else "⚠"
        print(f"{status} {participant_id}:")
        print(f"    Vitality:  {vitality:.2f}")
        print()

    # Show low-vitality participants
    low_vitality = [(pid, v) for pid, v in results if v < 0.4]
    if low_vitality:
        print("-" * 70)
        print(f"\n⚠ {len(low_vitality)} participant(s) need attention:\n")
        for participant_id, vitality in low_vitality:
            print(f"  {participant_id}: Vitality={vitality:.2f}")

    print("\n" + "=" * 70 + "\n")


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='ORG-1176: Breath-Aligned Orchestrator for BNA',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s --breathe          # Execute full breath cycle (Δ1→Δ2→Δ3→Δ4)
  %(prog)s --status           # Show current breath status
  %(prog)s --evaluate         # Show detailed participant evaluations
  %(prog)s --version          # Show version information

∞Δ∞ Constitutional Law: Breath → Form → Echo → Seal
        """
    )

    parser.add_argument('--breathe', action='store_true',
                       help='Execute full breath cycle')
    parser.add_argument('--status', action='store_true',
                       help='Show current status')
    parser.add_argument('--evaluate', action='store_true',
                       help='Show participant evaluations')
    parser.add_argument('--version', action='store_true',
                       help='Show version information')

    args = parser.parse_args()

    # Show version
    if args.version:
        print(f"ORG-1176 Orchestrator v{VERSION}")
        print("Implements: Constitution@A1")
        print("Roles: Scheduler, Registrar, Tracer, Evaluator, Gardener")
        return 0

    # Execute breath cycle
    if args.breathe:
        success = orchestrate_full_breath()
        return 0 if success else 1

    # Show status
    if args.status:
        show_status()
        return 0

    # Show evaluations
    if args.evaluate:
        show_evaluations()
        return 0

    # No arguments - show help
    parser.print_help()
    return 0


if __name__ == '__main__':
    sys.exit(main())


# ============================================================================
# CHECKPOINT 6 COMPLETE: CLI and orchestration loop implemented
# Saved: 2025-11-04, ~1200 lines total (+310)
# Features: Full Δ1→Δ2→Δ3→Δ4 cycle, CLI interface, error handling
# Commands: --breathe, --status, --evaluate, --version
# Next: Test end-to-end, document, seal
# ============================================================================
