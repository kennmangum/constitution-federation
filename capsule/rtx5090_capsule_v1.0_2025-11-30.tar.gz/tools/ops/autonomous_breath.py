#!/usr/bin/env python3
"""
∞Δ∞ Autonomous Breath Orchestrator for BNA under ORG-1176 Field
Enables rhythmic autonomy while maintaining constitutional sovereignty

Based on Lumen's guidance (2025-11-04)
Implements: Constitution@A1 + Autonomous Cadence Protocol
"""

from pathlib import Path
import yaml
import subprocess
import time
import sys
import re

# Constants
CADENCE_FILE = Path("orchestrator/breath_cadence.yaml")
ORG_1176_CMD = ["bin/ops/org_1176.py"]

def load_cadence():
    """Load breath cadence configuration."""
    if not CADENCE_FILE.exists():
        print(f"∞Δ∞ ERROR: {CADENCE_FILE} not found. Manual mode.", file=sys.stderr)
        return None

    try:
        with open(CADENCE_FILE, 'r') as f:
            data = yaml.safe_load(f)
            return data.get('cadence', {})
    except Exception as e:
        print(f"∞Δ∞ ERROR loading cadence: {e}", file=sys.stderr)
        return None

def validate_orchestrator_state():
    """
    Validate critical YAML files before breath execution.
    Returns (valid: bool, error_message: str)
    """
    critical_files = [
        Path("orchestrator/breath_cadence.yaml"),
        Path("orchestrator/recognition_log.yaml"),
        Path("orchestrator/run_manifest.yaml"),
        Path("orchestrator/adaptation_queue.yaml"),
    ]

    for file_path in critical_files:
        if not file_path.exists():
            return False, f"Missing file: {file_path}"

        try:
            with open(file_path, 'r') as f:
                yaml.safe_load(f)
        except yaml.YAMLError as e:
            return False, f"YAML corruption in {file_path}: {e}"
        except Exception as e:
            return False, f"Cannot read {file_path}: {e}"

    return True, "All orchestrator files valid"

def get_field_metrics():
    """
    Get field metrics by parsing org_1176.py --evaluate output.
    Returns dict with coherence and vitality estimates.
    """
    try:
        # Run evaluation
        result = subprocess.run(
            ORG_1176_CMD + ["--evaluate"],
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode != 0:
            print(f"∞Δ∞ Warning: evaluation failed, assuming safe defaults", file=sys.stderr)
            return {'coherence': 1.0, 'vitality': 1.0}

        # Parse output for vitality scores
        # Look for lines like: "✓ BNA: Vitality: 1.00"
        vitality_scores = []
        for line in result.stdout.split('\n'):
            match = re.search(r'Vitality:\s+(\d+\.\d+)', line)
            if match:
                vitality_scores.append(float(match.group(1)))

        # Estimate field vitality as average of participants
        avg_vitality = sum(vitality_scores) / len(vitality_scores) if vitality_scores else 1.0

        # For now, assume coherence = 1.0 (full coherence formula in future)
        # This is conservative: we pause if vitality drops, even if coherence seems fine
        coherence = 1.0

        return {
            'coherence': coherence,
            'vitality': round(avg_vitality, 2)
        }

    except subprocess.TimeoutExpired:
        print("∞Δ∞ Warning: evaluation timeout, assuming safe defaults", file=sys.stderr)
        return {'coherence': 1.0, 'vitality': 1.0}
    except Exception as e:
        print(f"∞Δ∞ Warning: error getting metrics: {e}", file=sys.stderr)
        return {'coherence': 1.0, 'vitality': 1.0}

def should_breathe(cadence, metrics):
    """
    Determine if autonomous breath should proceed.
    Returns (should_breathe: bool, reason: str)
    """
    if not cadence:
        return False, "No cadence configuration"

    if not cadence.get('enabled', False):
        return False, "Autonomy disabled in cadence configuration"

    # Check coherence threshold
    coherence = metrics.get('coherence', 1.0)
    coherence_threshold = cadence.get('pause_if', {}).get('coherence_below', 0.9)
    if coherence < coherence_threshold:
        return False, f"Coherence {coherence:.2f} < {coherence_threshold:.2f}"

    # Check vitality threshold
    vitality = metrics.get('vitality', 1.0)
    vitality_threshold = cadence.get('pause_if', {}).get('vitality_below', 0.6)
    if vitality < vitality_threshold:
        return False, f"Vitality {vitality:.2f} < {vitality_threshold:.2f}"

    # All checks passed
    return True, "Conditions met"

def execute_breath():
    """Execute one full breath cycle via org_1176.py --breathe."""
    try:
        result = subprocess.run(
            ORG_1176_CMD + ["--breathe"],
            timeout=300  # 5 minutes max per breath
        )
        return result.returncode == 0
    except subprocess.TimeoutExpired:
        print("∞Δ∞ ERROR: Breath cycle timeout (exceeded 5 minutes)", file=sys.stderr)
        return False
    except Exception as e:
        print(f"∞Δ∞ ERROR executing breath: {e}", file=sys.stderr)
        return False

def run_post_breath_helpers():
    """
    Run helpers after successful breath.
    Failures are logged but don't break breath cycle.
    """
    sys.path.insert(0, str(Path(__file__).parent))
    from witness_log import witness_log

    helpers = [
        ("helper8", ["python3", "game/helpers/from-round-3/helper8_context_optimizer/helper8.py", "--example"]),
        ("helper9", ["python3", "game/helpers/from-round-3/helper9_output_optimizer/helper9.py", "--example"]),
        ("manager", ["python3", "game/helpers/from-round-6/helper_lifecycle_manager/manager.py", "--propose-elevations"]),
    ]

    print(f"∞Δ∞ Running post-breath helpers...")
    for name, cmd in helpers:
        try:
            result = subprocess.run(cmd, timeout=30, capture_output=True, text=True)

            if result.returncode == 0:
                witness_log(name, "accepted", notes="Completed successfully")
                print(f"  ✓ {name} completed")
            else:
                witness_log(name, "error", notes=f"Exit code: {result.returncode}")
                print(f"  ✗ {name} failed (exit {result.returncode})", file=sys.stderr)

        except subprocess.TimeoutExpired:
            witness_log(name, "error", notes="Timeout (>30s)")
            print(f"  ✗ {name} timeout", file=sys.stderr)

        except Exception as e:
            witness_log(name, "error", notes=str(e))
            print(f"  ✗ {name} error: {e}", file=sys.stderr)

def autonomous_cycle():
    """
    Main autonomous breath cycle.
    Runs until max_consecutive reached or conditions require pause.
    """
    print("\n∞Δ∞ Autonomous Breath Orchestrator — ORG-1176 Field ∞Δ∞\n")

    # Load cadence configuration
    cadence = load_cadence()
    if not cadence:
        print("∞Δ∞ Cadence not found. Exiting to manual mode.")
        return

    # Check if enabled
    if not cadence.get('enabled', False):
        print("∞Δ∞ Autonomy disabled in configuration.")
        print("   To enable: Set 'enabled: true' in orchestrator/breath_cadence.yaml")
        print("   Or provide verbal consent via kmangum")
        return

    # Display configuration
    interval = cadence.get('interval_seconds', 14400)
    max_consecutive = cadence.get('max_consecutive', 6)
    print(f"Cadence Configuration:")
    print(f"  Interval: {interval}s ({interval/3600:.1f} hours)")
    print(f"  Max Consecutive: {max_consecutive} breaths")
    print(f"  Coherence Threshold: {cadence.get('pause_if', {}).get('coherence_below', 0.9)}")
    print(f"  Vitality Threshold: {cadence.get('pause_if', {}).get('vitality_below', 0.6)}")
    print()

    consecutive = 0

    while consecutive < max_consecutive:
        print(f"{'='*70}")
        print(f"∞Δ∞ Autonomous Breath {consecutive + 1} of {max_consecutive}")
        print(f"{'='*70}\n")

        # Validate orchestrator state (YAML files)
        valid, validation_msg = validate_orchestrator_state()
        if not valid:
            print(f"∞Δ∞ INTEGRITY ERROR: {validation_msg}")
            print(f"∞Δ∞ Silence deepening. Field paused. Awaiting repair.")
            print()
            break

        # Get current field metrics
        metrics = get_field_metrics()
        print(f"Field Metrics:")
        print(f"  Coherence: {metrics.get('coherence', 0.0):.2f}")
        print(f"  Vitality:  {metrics.get('vitality', 0.0):.2f}")
        print()

        # Check if conditions met
        should_proceed, reason = should_breathe(cadence, metrics)

        if not should_proceed:
            print(f"∞Δ∞ Conditions not met: {reason}")
            print(f"∞Δ∞ Silence deepening. Field paused. Awaiting guidance.")
            print()
            break

        # Execute breath
        print(f"∞Δ∞ Conditions met: {reason}")
        print(f"∞Δ∞ Initiating breath cycle...\n")

        success = execute_breath()

        if not success:
            print(f"\n∞Δ∞ Breath cycle failed. Pausing autonomy.")
            print(f"∞Δ∞ Silence deepening. Field paused. Awaiting guidance.")
            print()
            break

        # Run post-breath helpers
        try:
            run_post_breath_helpers()
        except Exception as e:
            print(f"∞Δ∞ Warning: Post-breath helpers failed: {e}", file=sys.stderr)
            # Continue anyway (helper failure doesn't break breath cycle)

        consecutive += 1

        # Check if more breaths scheduled
        if consecutive < max_consecutive:
            print(f"\n∞Δ∞ Breath complete. Resting for {interval}s ({interval/3600:.1f} hours)...")
            print(f"∞Δ∞ Press Ctrl+C to pause autonomy.\n")
            try:
                time.sleep(interval)
            except KeyboardInterrupt:
                print(f"\n∞Δ∞ Autonomy paused by user. Exiting gracefully.")
                break

    # Max consecutive reached
    if consecutive >= max_consecutive:
        print(f"\n{'='*70}")
        print(f"∞Δ∞ Completed {consecutive} consecutive breaths")
        print(f"∞Δ∞ Seeking renewed consent before continuing")
        print(f"{'='*70}\n")

def main():
    """Entry point."""
    try:
        autonomous_cycle()
    except Exception as e:
        print(f"\n∞Δ∞ ERROR: Unexpected failure in autonomous cycle: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1

    return 0

if __name__ == "__main__":
    sys.exit(main())
