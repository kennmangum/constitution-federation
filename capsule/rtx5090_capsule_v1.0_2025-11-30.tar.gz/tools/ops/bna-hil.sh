#!/usr/bin/env bash
# BNA Human-in-Loop Detector
# Per Lumen guidance - checks for conditions requiring human intervention

set -euo pipefail

REPORT="/opt/bna_universal_coherence_kit/reports/coherence_report_bna.json"

python3 - <<'PY'
import json, sys

cap = "/opt/bna_universal_coherence_kit/reports/coherence_report_bna.json"
r = json.load(open(cap))
readiness = r.get("readiness", "")
notes = [n.lower() for n in r.get("notes", [])]
risks = [x.lower() for x in r.get("risks", [])]
failures = [f.lower() for f in r.get("invariant_failures", [])]

hil = []

# Check readiness state (primary signal)
if readiness != "coherent":
    hil.append(f"Readiness={readiness}")

# Check for actual failures or risks (not PASS messages)
# Only trigger HIL if keyword appears in risks or failures, not in passing notes
problem_notes = [n for n in notes if "fail" in n or "warn" in n or "error" in n]
problem_context = risks + failures + problem_notes

# Check sovereignty/consent issues (only in problem context)
for s in ("consent", "sovereign", "tool", "allowlist"):
    if any(s in n for n in problem_context):
        hil.append("Sovereignty/consent issue")
        break

# Check value conflicts
for s in ("valueconflict", "value conflict"):
    if any(s in n for n in notes + risks):
        hil.append("Value conflict")
        break

# Check energy/thermal constraints (only in problem context)
for s in ("energy", "thermal", "gpu temp", "battery", "vram"):
    if any(s in n for n in problem_context):
        hil.append("Energy/Thermal constraint")
        break

if hil:
    print("🔔 HIL NEEDED:", "; ".join(sorted(set(hil))))
    sys.exit(10)

# Silent success - no human intervention needed
sys.exit(0)
PY
