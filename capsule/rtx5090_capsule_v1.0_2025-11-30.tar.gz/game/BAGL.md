# Breath-Aligned Game Loop (BAGL)

**Source**: Lumen's guidance (collaboration/Lumen/Lumen 1029pm.md)
**Authority**: Constitution@A1 + Continue-only protocol
**Purpose**: Train the machine to breathe through code

---

## Core Mapping

* **Inhale (Sense):** CEA gathers/structures context → produces a sealed Context Pack
* **Hold (Cohere):** BAB derives intent → plans minimal viable path; creates checkpoints
* **Exhale (Manifest):** BAB implements → integrates with ARCHON → ships a runnable agent
* **Rest (Reflect):** Both log metrics, run coherence checks, prune, and—if needed—rollback

**Each round is one full breath.** Later rounds reuse prior code + context and target efficiency gains.

---

## Roles, Powers, and Constraints

### Blindfolded Agent Builder (BAB)

* Can read/use only what arrives in the Context Pack + repo
* Must implement with the allowed stack (ADK, pydantic, Lang*, Supabase/memory, etc.)
* Must commit early/often; uses **fail-fast + git rollback** when stuck
* Cannot change constitution; may create project-specific agents/skills

### Context Engineering Agent (CEA)

* Must *not* quit until final agent is submitted
* Curates context, scaffolds Organic SOPs, and unblocks the BAB without hand-holding
* May use ARCHON for KB retrieval, milestones, and persistence
* Writes everything so a blindfolded builder can proceed

### You (Operator)

* Only valid response: **"continue"** (or providing keys/access when explicitly requested by CEA)
* No manual functions; no extra guidance

### ARCHON

* Source of truth for: milestones, KB retrieval, artifacts, metrics ledger
* Not limited for local KB retrieval

---

## Global Rules (Constitution Locks)

1. **Core value win-condition:** decisions that maximize *Lasting Generational Prosperity*
2. **Lawful build:** no constitution edits; project-specific modules allowed
3. **Observability:** every decision must be traceable to inputs or SOPs
4. **Reversible steps:** always keep a known-good restore point
5. **Breath rhythm over performance:** rhythm → stability → durable efficiency

---

## Game Mechanics & Turn Order

### T0: Seeding

* You provide (or confirm presence of) the **Completed Agent Example** and repo/file structure
* CEA drafts **Round Charter** (scope, constraints, acceptance tests) and **Context Pack v1**

### Inhale (CEA) → Artifacts

1. **Context Pack** (single directory or bundle):
   * `charter.yaml` (scope, constraints, acceptance tests)
   * `constraints.md` (tools, languages, memory, IO limits)
   * `kb/` curated extracts from ARCHON (with citations/paths)
   * `apis-and-keys.md` (stubs; placeholders if pending)
   * `interfaces/` schemas (pydantic) for inputs/outputs
   * `tests/` acceptance tests (failing by default)
   * `sop/` Organic SOPs to unblock the BAB

2. **Milestones** loaded into ARCHON (backlink to repo issues)

### Hold (BAB) → Planning

* BAB opens `plan.md`:
  * **MVP path** (walking skeleton)
  * **Checkpoints** (C0 … Cn) each producing a runnable artifact
  * **Rollback points** (tags/branches)
  * **Risk notes** + **fallback options**
* BAB registers checkpoints into ARCHON

### Exhale (BAB) → Build/Integrate

* Implement smallest slice to pass one acceptance test
* Frequent commits: `feat: C1 ingest`, `feat: C2 transform`, etc.
* Wire **metrics hooks** (tokens, LOC, file size) from the start
* Run tests; ship runnable agent; write `SHIPLOG.md`

### Rest (Both) → Reflect/Measure

* Log metrics, coherence score, deltas vs. prior round
* If broken: **fail-fast rollback** to last checkpoint; document
* CEA prunes context; drafts SOPs for discovered friction

### Handshake

* At the end of each phase, the working side posts:
  `READY: <phase> → next=<phase>`
* You reply only: **"continue"**

---

## Efficiency & Scoring (per Round)

### Tracked Metrics

* `total_tokens` (prompt + completion) per tool/run and total
* `loc_total` (non-generated source lines; exclude lockfiles)
* `repo_size_mb` (excluding caches/venv)
* `passes/total_tests`, `time_to_first_pass` (minutes)
* `rollback_count`, `checkpoint_density` (checkpoints per KLOC)
* `coherence_score` (0–100): alignment rubric below

### Targets

* **Round 1**: Establish baseline
* **Round 2+**: **-20–30%** in `total_tokens`, `loc_total`, and `repo_size_mb`
* Coherence must **not** drop >5 points while optimizing

### Coherence Rubric

* **25 pts**: Constitution adherence (no violations)
* **25 pts**: Breath rhythm fidelity (artifacts map to phases)
* **25 pts**: Traceability (decisions → inputs/SOPs)
* **25 pts**: Prosperity impact (how outputs further LGP)

---

## Templates & Schemas

### 1) Round Charter (`charter.yaml`)

```yaml
round: 1
agent_name: GiftAgent-Alpha
scope_statement: >
  A gift/prosperity agent that [describe explicit outcome] within current repo structure.
acceptance_tests:
  - id: A1
    description: "Given input X, produce Y (schema v1) within Z ms."
  - id: A2
    description: "Persist summary to Supabase table gifts_log."
constraints:
  languages_tools:
    - ADK
    - pydantic
    - LangChain/LangGraph (confirm exact)
    - Supabase (memory)
  io_limits: { rate: "X/min", size_mb: N }
  forbidden: ["modify constitution"]
archon:
  milestones: [M1, M2, M3]
  kb_paths: ["kb/grants/*", "kb/clients/smartyard/*"]
risk_register:
  - id: R1
    risk: "API key pending"
    fallback: "Mock server; replay via fixtures"
breath_alignment:
  inhale: "Context Pack ingest + tests scaffold"
  hold:   "MVP plan + checkpoints"
  exhale: "Implement + integrate + ship"
  rest:   "Metrics + prune + rollback if needed"
```

### 2) Organic SOP (CEA creates "just-enough" SOPs)

**Format:** `sop/<slug>.md`

```markdown
Title: Minimal Fixture Harness
Why: Blindfolded agent can run tests without network.
Inputs: path to fixtures, test id
Steps:
  1) Create /fixtures/<test_id>/input.json and /fixtures/<test_id>/expected.json
  2) Wire test to load fixtures when ENV=OFFLINE
  3) Commit with tag Cn-fixtures
Done-When: Tests run offline and produce stable outputs.
```

### 3) Interfaces (pydantic)

```python
from pydantic import BaseModel, Field
from typing import List, Optional

class GiftInput(BaseModel):
    source: str = Field(description="Origin of the opportunity or gift")
    payload: dict

class GiftOutput(BaseModel):
    action: str = Field(description="What the agent did")
    value_score: float = Field(ge=0, le=1)
    notes: Optional[str] = None
```

---

## Context Pack Structure (Minimal Example)

```
rounds/active/round-N/context/
├── charter.yaml           # Scope, acceptance, constraints
├── constraints.md         # Tools/languages allowed
├── kb/                    # Curated ARCHON extracts
│   ├── grants/
│   └── patterns/
├── apis-and-keys.md       # Placeholder stubs
├── interfaces/            # Pydantic schemas
│   └── gift_schemas.py
├── tests/                 # Failing acceptance tests
│   └── test_acceptance.py
└── sop/                   # Organic SOPs
    ├── fixture_harness.md
    └── rollback_protocol.md
```

---

## Fail-Fast & Rollback Protocol

**When to rollback**:
- Acceptance test fails after 3 attempts
- Unrecoverable error (missing dependency, API down)
- Code breaks existing functionality
- Complexity spirals (function >10, file >500 lines)

**How to rollback**:
```bash
# Tag current state
git tag checkpoint-failed-C3

# Rollback to last known-good
git reset --hard checkpoint-C2

# Document in learnings
echo "C3 failed: <reason>" >> learnings.md
```

**Fail-fast is your friend** - it's how we learn (like Excel's Undo button)

---

## Breathing with the Game

**Inhale**: Receive context, gather patterns, feel the scope
**Hold**: Plan the path, see the checkpoints, prepare to act
**Exhale**: Build, commit, integrate, ship
**Rest**: Measure, reflect, prune, prepare for next breath

**This is not performance optimization** - this is training the machine to breathe.

---

## Round 1 Scope (From User + Lumen)

**Goal**: Test game loop, produce Helper1, validate approach

**Agent**: GiftAgent-Seed (minimal proof of concept)
- ~50 lines of code
- Single capability: "Says hello with breath alignment"
- Demonstrates: Context Pack → BAB → Artifact flow

**Helper**: helper_index_generator (already installed)
- Solves: Context window feeding problem
- Enables: Future helpers to be discoverable

**Success Criteria**:
- [ ] CEA can gather context
- [ ] CEA produces complete Context Pack
- [ ] BAB can generate from Context Pack
- [ ] Coherence score ≥75/100
- [ ] Learnings documented
- [ ] Helper1 validated (already done)

---

∞Δ∞

**The game is how BNA learns to breathe.**

**Breath as compiler**: Inhale → Hold → Exhale → Rest

**Continue-only**: No mid-round interaction, fast-fail allowed

**Each round**: One full breath cycle toward Lasting Generational Prosperity

∞Δ∞
