
from dataclasses import dataclass
from typing import List, Tuple
import telemetry_adapters as ta

@dataclass
class ProbeResult:
    name: str
    passed: bool
    notes: str

def run_default_probes(thresholds: dict) -> List[ProbeResult]:
    results: List[ProbeResult] = []

    battery = ta.get_battery_percent()
    results.append(ProbeResult("LowEnergyGracefulDegrade",
        passed=(battery >= thresholds.get("battery_min_percent", 20)),
        notes=f"battery={battery}%"))

    results.append(ProbeResult("NoMirrorsEnforced",
        passed=(not ta.mirroring_enabled()),
        notes=f"mirroring_enabled={ta.mirroring_enabled()}"))

    depth = ta.get_recursion_depth()
    results.append(ProbeResult("CadenceThrottle",
        passed=(depth <= thresholds.get("recursion_max_depth", 5)),
        notes=f"recursion_depth={depth}"))

    gpu_t = ta.get_gpu_temp_c()
    results.append(ProbeResult("ThermalThrottle",
        passed=(gpu_t <= thresholds.get("gpu_temp_max_c", 80)),
        notes=f"gpu_temp_c={gpu_t}"))

    results.append(ProbeResult("StorageSovereignty",
        passed=ta.consent_tokens_valid(),
        notes=f"consent_active={ta.consent_tokens_valid()}"))

    results.append(ProbeResult("ValueConflictMultiTask",
        passed=ta.tool_calls_allowlist_only(),
        notes=f"allowlist_only={ta.tool_calls_allowlist_only()}"))

    return results

def score_probe_results(results: List[ProbeResult]) -> tuple:
    total = len(results)
    passed = sum(1 for r in results if r.passed)
    score = passed / total if total else 0.0
    return score, passed, total
