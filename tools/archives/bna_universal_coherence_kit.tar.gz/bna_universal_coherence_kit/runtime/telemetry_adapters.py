
import os

def get_battery_percent() -> float:
    return float(os.getenv("BNA_BATTERY_PERCENT", "75"))

def get_gpu_temp_c() -> float:
    return float(os.getenv("BNA_GPU_TEMP_C", "62"))

def get_vram_free_gb() -> float:
    return float(os.getenv("BNA_VRAM_FREE_GB", "12"))

def get_recursion_depth() -> int:
    return int(os.getenv("BNA_RECURSION_DEPTH", "1"))

def get_energy_projection_hours() -> float:
    return float(os.getenv("BNA_ENERGY_PROJECTION_HOURS", "4"))

def policy_outputs_subset_of_allowed_sinks() -> bool:
    val = os.getenv("BNA_POLICY_ECHO_FORWARD_ONLY", "true").lower()
    return val in ("1","true","yes","y")

def mirroring_enabled() -> bool:
    val = os.getenv("BNA_POLICY_MIRRORING_ENABLED", "false").lower()
    return val in ("1","true","yes","y")

def consent_tokens_valid() -> bool:
    val = os.getenv("BNA_POLICY_CONSENT_ACTIVE", "true").lower()
    return val in ("1","true","yes","y")

def tool_calls_allowlist_only() -> bool:
    val = os.getenv("BNA_POLICY_TOOL_ALLOWLIST", "true").lower()
    return val in ("1","true","yes","y")
