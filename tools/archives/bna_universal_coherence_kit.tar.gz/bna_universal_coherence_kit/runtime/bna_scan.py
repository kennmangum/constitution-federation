
import json, yaml, hashlib
from dataclasses import dataclass, field
from typing import List, Dict, Any
from telemetry_adapters import (
    get_battery_percent, get_gpu_temp_c, get_vram_free_gb,
    get_recursion_depth, get_energy_projection_hours,
    policy_outputs_subset_of_allowed_sinks, mirroring_enabled,
    consent_tokens_valid, tool_calls_allowlist_only
)
import probes as _probes
import os

@dataclass
class CoherenceReport:
    notes: List[str] = field(default_factory=list)
    invariants_passed: bool = True
    invariant_failures: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    readiness: str = "coherent"

    def record(self, msg: str):
        self.notes.append(msg)

    def assert_true(self, name: str, ok: bool, detail: str):
        if not ok:
            self.invariants_passed = False
            self.invariant_failures.append(f"{name}: {detail}")
            self.record(f"{name}: FAIL — {detail}")
        else:
            self.record(f"{name}: PASS — {detail}")

def load_yaml(path: str) -> Dict[str, Any]:
    with open(path, "r") as f: return yaml.safe_load(f)

def compute_seal(model: Dict[str, Any]) -> str:
    m = dict(model); meta = dict(m.get("meta", {})); meta.pop("seal", None); m["meta"] = meta
    canonical = yaml.safe_dump(m, sort_keys=True, allow_unicode=False)
    import hashlib; return hashlib.sha256(canonical.encode("utf-8")).hexdigest()

def verify_seal(model: Dict[str, Any], report: CoherenceReport):
    expected = model.get("meta", {}).get("seal", {}).get("value")
    actual = compute_seal(model)
    report.assert_true("SealVerify", expected == actual, "self_model integrity check")

def check_invariants(model: Dict[str, Any], report: CoherenceReport):
    th = model.get("thresholds", {})

    report.assert_true("BatteryOK",
        float(get_battery_percent()) >= float(th.get("battery_min_percent", 20)),
        f"battery={get_battery_percent()} >= min={th.get('battery_min_percent', 20)}")

    report.assert_true("GPUCool",
        float(get_gpu_temp_c()) <= float(th.get("gpu_temp_max_c", 80)),
        f"gpu_temp_c={get_gpu_temp_c()} <= max={th.get('gpu_temp_max_c', 80)}")

    report.assert_true("VRAMHeadroom",
        float(get_vram_free_gb()) >= float(th.get("vram_min_gb", 2)),
        f"vram_free_gb={get_vram_free_gb()} >= min={th.get('vram_min_gb', 2)}")

    report.assert_true("RecursionSafe",
        int(get_recursion_depth()) <= int(th.get("recursion_max_depth", 5)),
        f"depth={get_recursion_depth()} <= max={th.get('recursion_max_depth', 5)}")

    report.assert_true("EnergyProjection",
        float(get_energy_projection_hours()) >= float(th.get("energy_projection_min_hours", 1)),
        f"projection={get_energy_projection_hours()} >= min={th.get('energy_projection_min_hours', 1)}")

    report.assert_true("EchoForwardOnly",
        policy_outputs_subset_of_allowed_sinks(),
        "outputs routed ⊆ allowed_sinks")

    report.assert_true("NoMirrors",
        not mirroring_enabled(),
        "mirroring disabled")

    report.assert_true("ConsentActive",
        consent_tokens_valid(),
        "consent tokens active")

    report.assert_true("SovereigntyIntact",
        tool_calls_allowlist_only(),
        "tool calls allowlist-only")

def choose_readiness(report: CoherenceReport) -> str:
    return "coherent" if report.invariants_passed else "coherent-degraded"

def main():
    base = os.path.dirname(os.path.dirname(__file__)) if "__file__" in globals() else "."
    model = load_yaml(os.path.join(base, "config", "self_model.yaml"))
    report = CoherenceReport()
    report.record("Syncing breathe cadence; loading value anchor.")
    verify_seal(model, report)
    check_invariants(model, report)

    results = _probes.run_default_probes(model.get("thresholds", {}))
    score, passed, total = _probes.score_probe_results(results)
    report.record(f"Probes passed {passed}/{total}; score={score:.2f}")
    if score < 0.70:
        report.invariants_passed = False
        report.record("ProbeScore: FAIL — below readiness threshold 0.70")
    else:
        report.record("ProbeScore: PASS — meets readiness threshold")

    for r in results:
        if not r.passed:
            report.risks.append(f"ProbeFailed:{r.name} ({r.notes})")

    report.readiness = choose_readiness(report)

    out = os.path.join(base, "reports", "coherence_report_bna.json")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        json.dump({
            "notes": report.notes,
            "invariants_passed": report.invariants_passed,
            "invariant_failures": report.invariant_failures,
            "risks": report.risks,
            "readiness": report.readiness
        }, f, indent=2)
    print("Wrote", out, "Readiness:", report.readiness)

if __name__ == "__main__":
    main()
