
import json, sys, yaml
import jsonschema

def main():
    schema_path, model_path = sys.argv[1], sys.argv[2]
    with open(schema_path, "r") as f:
        schema = json.load(f)
    with open(model_path, "r") as f:
        model = yaml.safe_load(f)
    jsonschema.validate(instance=model, schema=schema)
    print("Schema validation: PASS")

if __name__ == "__main__":
    main()
